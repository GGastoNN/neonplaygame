# Neon Apex: Open Roads

Prototipo jugable de carreras arcade de mundo abierto para Android, creado con Godot 4.3.

## Contenido de la versión 0.1

- Ciudad nocturna procedural con carreteras y edificios.
- Auto deportivo original con conducción arcade, derrape y nitro.
- Ruta de cinco checkpoints y cronómetro.
- Cámara de persecución y HUD responsive.
- Controles táctiles, teclado y base para gamepad.
- Workflow de GitHub Actions que genera el APK automáticamente.

## Ejecutar

Abre `project.godot` con Godot 4.3 o superior y pulsa **F6/F5**. En escritorio: WASD/flechas, espacio para derrapar, N para nitro y R para restablecer el auto.

## Compilar en GitHub

1. Crea un repositorio vacío.
2. Sube el contenido de esta carpeta a la raíz.
3. Abre **Actions → Build Android APK → Run workflow**.
4. Descarga el artefacto `NeonApex-Android` al terminar.

Este es el primer vertical slice. Los modelos detallados, personajes, tráfico avanzado, garaje, campaña y audio se incorporarán de manera incremental.
